const hadiths = [
  {text:"مَن دلَّ على خيرٍ فله مثلُ أجر فاعله", source:"رواه مسلم", explain:"في الحديث فضل الدلالة على الخير، وأن من أعان على الطاعة نال مثل أجر فاعلها."},
  {text:"إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى", source:"متفق عليه", explain:"يبين الحديث مكانة النية، وأن قبول العمل وأجره مرتبطان بما قصده الإنسان."},
  {text:"خيركم من تعلم القرآن وعلمه", source:"رواه البخاري", explain:"فضل تعلم كتاب الله وتعليمه للناس، وهو من أعظم أبواب الخير."}
];
const adhkar = {
  morning:[["أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.",1],["اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور.",1],["رضيت بالله ربًا، وبالإسلام دينًا، وبمحمد ﷺ نبيًا.",3]],
  evening:[["أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له.",1],["اللهم إني أسألك العفو والعافية في الدنيا والآخرة.",1],["رضيت بالله ربًا، وبالإسلام دينًا، وبمحمد ﷺ نبيًا.",3]],
  sleep:[["باسمك اللهم أموت وأحيا.",1],["اللهم قني عذابك يوم تبعث عبادك.",3],["سبحان الله",33],["الحمد لله",33],["الله أكبر",34]]
};
let dhikrCounts={}, currentHadith=0;
function renderAdhkar(category="morning"){
  const list=document.getElementById("adhkar-list"); if(!list)return; list.innerHTML="";
  (adhkar[category]||[]).forEach((item,i)=>{const key=category+"-"+i;dhikrCounts[key]=dhikrCounts[key]||0;
    const div=document.createElement("div");div.className="dhikr";
    div.innerHTML=`<p>${item[0]}</p><div class="dhikr-foot"><span>التكرار المقترح: ${item[1]}</span><button class="count-btn" onclick="countDhikr('${key}',${item[1]},this)">تم التكرار 0/${item[1]}</button></div>`;
    list.appendChild(div);});
}
function countDhikr(key,total,btn){dhikrCounts[key]=(dhikrCounts[key]||0)+1;if(dhikrCounts[key]>total)dhikrCounts[key]=0;btn.textContent=`تم التكرار ${dhikrCounts[key]}/${total}`;}
function resetDhikr(){dhikrCounts={};renderAdhkar(document.querySelector(".tab.active")?.dataset.category||"morning");}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderAdhkar(btn.dataset.category);}));
function renderHadith(){const h=hadiths[currentHadith%hadiths.length];document.getElementById("hadith-text").textContent=`«${h.text}»`;document.getElementById("hadith-source").textContent=h.source;document.getElementById("hadith-explain").textContent=h.explain;}
function nextHadith(){currentHadith=(currentHadith+1)%hadiths.length;renderHadith();}
async function loadPrayerTimes(){
  const status=document.getElementById("prayer-status"),box=document.getElementById("live-times"); if(!box)return;
  status.textContent="جاري تحميل المواقيت...";
  const names={Fajr:"الفجر",Sunrise:"الشروق",Dhuhr:"الظهر",Asr:"العصر",Maghrib:"المغرب",Isha:"العشاء"};
  try{const d=new Date();document.getElementById("prayer-date").textContent=`عمّان - الأردن • ${d.toLocaleDateString("ar-JO")}`;
    const date=d.toISOString().slice(0,10).split("-").reverse().join("-");
    const res=await fetch(`https://api.aladhan.com/v1/timingsByCity/${date}?city=Amman&country=Jordan&method=4`);
    if(!res.ok)throw new Error("network");const t=(await res.json()).data.timings;
    box.innerHTML=Object.entries(names).map(([k,n])=>`<div class="live-time"><span class="name">${n}</span><span class="time">${t[k]}</span></div>`).join("");
    status.textContent="تم تحديث المواقيت حسب تاريخ اليوم.";
  }catch(e){const f={Fajr:"04:42",Sunrise:"06:07",Dhuhr:"12:50",Asr:"16:24",Maghrib:"19:03",Isha:"20:22"};
    box.innerHTML=Object.entries(names).map(([k,n])=>`<div class="live-time"><span class="name">${n}</span><span class="time">${f[k]}</span></div>`).join("");
    status.textContent="تعذر الاتصال؛ عُرضت أوقات احتياطية تجريبية.";}
}
function doSearch(){const q=document.getElementById('search').value.trim();if(!q){alert('اكتب كلمة للبحث أولاً');return;}document.getElementById('quran-search').value=q;document.getElementById('quran-app').scrollIntoView({behavior:'smooth'});searchQuran();}

const SURAH_NAMES=["الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"];
const API="https://api.alquran.cloud/v1";
const CDN="https://cdn.islamic.network/quran";
let currentSurah=1, currentAyahs=[], tafsirEdition="ar.muyassar";

function renderSurahList(filter=""){
  const list=document.getElementById("surah-list"); if(!list)return;
  const f=filter.trim().toLowerCase();
  list.innerHTML=SURAH_NAMES.map((name,i)=>({n:i+1,name})).filter(s=>!f||s.name.includes(f)||String(s.n).includes(f)).map(s=>`
    <button class="surah-item ${s.n===currentSurah?'active':''}" onclick="openSurah(${s.n})">
      <span class="surah-number">${s.n}</span><span><span class="surah-name">سورة ${s.name}</span><span class="surah-sub">اضغط للقراءة والاستماع</span></span>
    </button>`).join("");
}
function filterSurahs(){renderSurahList(document.getElementById("surah-filter").value);}

async function openSurah(num, ayahToScroll=null){
  currentSurah=num;renderSurahList(document.getElementById("surah-filter")?.value||"");
  const title=document.getElementById("surah-title"),info=document.getElementById("surah-info"),load=document.getElementById("quran-loading"),list=document.getElementById("ayah-list"),results=document.getElementById("search-results");
  results.classList.add("hidden");list.innerHTML="";load.textContent="جاري تحميل سورة "+SURAH_NAMES[num-1]+"...";
  title.textContent="سورة "+SURAH_NAMES[num-1];info.textContent="جاري جلب الآيات والتفسير...";
  try{
    const [qRes,tRes]=await Promise.all([
      fetch(`${API}/surah/${num}/quran-uthmani-quran-academy`),
      fetch(`${API}/surah/${num}/${tafsirEdition}`)
    ]);
    if(!qRes.ok)throw new Error("quran");
    const qData=(await qRes.json()).data;currentAyahs=qData.ayahs;
    let tafsir={ayahs:[]}; if(tRes.ok){try{tafsir=(await tRes.json()).data}catch(e){}}
    document.getElementById("surah-revelation").textContent=qData.revelationType==="Meccan"?"مكية":"مدنية";
    info.textContent=`${qData.numberOfAyahs} آية • ${qData.revelationType==="Meccan"?"مكية":"مدنية"}`;
    list.innerHTML=currentAyahs.map((a,i)=>{
      const tx=tafsir.ayahs?.[i]?.text||"التفسير غير متاح حاليًا.";
      return `<article class="ayah" id="ayah-${a.numberInSurah}" data-global="${a.number}">
        <div class="ayah-top"><span class="ayah-num">${a.numberInSurah}</span><div class="ayah-tools">
          <button onclick="playAyah(${a.number})">▶ استماع</button><button onclick="toggleTafsir(${a.numberInSurah})">تفسير</button><button onclick="saveAyah(${a.numberInSurah})">🔖 حفظ</button>
        </div></div>
        <div class="ayah-text">${a.text} ۝</div>
        <div class="tafsir" id="tafsir-${a.numberInSurah}"><b>التفسير:</b> ${tx}</div>
      </article>`;
    }).join("");
    load.textContent="";
    document.getElementById("quran-player").src=`${CDN}/audio-surah/128/${document.getElementById("reciter")?.value||"ar.alafasy"}/${num}.mp3`;
    restoreSavedHighlight();
    if(ayahToScroll) setTimeout(()=>document.getElementById("ayah-"+ayahToScroll)?.scrollIntoView({behavior:"smooth",block:"center"}),200);
  }catch(e){
    load.textContent="تعذر تحميل القرآن من المصدر الخارجي. تحقق من الاتصال بالإنترنت ثم حاول مرة أخرى.";
  }
}
function toggleTafsir(n){document.getElementById("tafsir-"+n)?.classList.toggle("open");}
function toggleTafsirAll(){document.querySelectorAll(".tafsir").forEach(x=>x.classList.toggle("open"));}
function playAyah(globalNumber){document.getElementById("quran-player").src=`${CDN}/audio/128/${document.getElementById("reciter")?.value||"ar.alafasy"}/${globalNumber}.mp3`;document.getElementById("quran-player").play().catch(()=>{alert("اضغط تشغيل من مشغل الصوت بعد تحميل السورة.");});}
document.getElementById("reciter")?.addEventListener("change",()=>{document.getElementById("quran-player").src=`${CDN}/audio-surah/128/${document.getElementById("reciter")?.value||"ar.alafasy"}/${currentSurah}.mp3`;});

function savePosition(num=currentSurah,ayah=1){
  localStorage.setItem("zadLastRead",JSON.stringify({surah:num,ayah}));updateLastRead();updateProgress();
}
function saveCurrentPosition(){const visible=document.querySelector(".ayah.saved")?.id?.split("-")[1]||1;savePosition(currentSurah,Number(visible));alert("تم حفظ موضع القراءة.");}
function saveAyah(ayah){document.querySelectorAll(".ayah").forEach(x=>x.classList.remove("saved"));document.getElementById("ayah-"+ayah)?.classList.add("saved");savePosition(currentSurah,ayah);}
function updateLastRead(){
  const el=document.getElementById("last-read"),raw=localStorage.getItem("zadLastRead");
  if(!raw){el.textContent="لم تبدأ القراءة بعد";return;}
  const x=JSON.parse(raw);el.textContent=`آخر قراءة: سورة ${SURAH_NAMES[x.surah-1]} • الآية ${x.ayah}`;
}
function restoreSavedHighlight(){
  const raw=localStorage.getItem("zadLastRead");if(!raw)return;const x=JSON.parse(raw);
  if(x.surah===currentSurah)document.getElementById("ayah-"+x.ayah)?.classList.add("saved");
}
function continueReading(){
  const raw=localStorage.getItem("zadLastRead");if(!raw){document.getElementById("quran-app").scrollIntoView({behavior:"smooth"});openSurah(1);return;}
  const x=JSON.parse(raw);document.getElementById("quran-app").scrollIntoView({behavior:"smooth"});openSurah(x.surah,x.ayah);
}
async function searchQuran(){
  const q=document.getElementById("quran-search").value.trim();const box=document.getElementById("search-results");const list=document.getElementById("ayah-list");
  if(!q){box.classList.add("hidden");return;}
  box.classList.remove("hidden");box.innerHTML='<div class="status">جاري البحث في القرآن الكريم...</div>';list.innerHTML="";
  try{
    const res=await fetch(`${API}/search/${encodeURIComponent(q)}/all/ar`);
    if(!res.ok)throw new Error("search");const data=(await res.json()).data;
    if(!data.matches?.length){box.innerHTML='<div class="status">لم يتم العثور على نتائج.</div>';return;}
    box.innerHTML=`<div class="status">تم العثور على ${data.count} نتيجة</div>`+data.matches.slice(0,80).map(m=>`<div class="result"><b>سورة ${m.surah.name} • الآية ${m.numberInSurah}</b><p>${m.text}</p><small>اضغط للانتقال إلى السورة</small><br><button class="outline" onclick="openSurah(${m.surah.number},${m.numberInSurah})">فتح الآية</button></div>`).join("");
  }catch(e){box.innerHTML='<div class="status">تعذر إجراء البحث الآن. حاول مرة أخرى.</div>';}
}

document.querySelector('.menu')?.addEventListener('click',()=>{
  const links=document.querySelector('.links');links.style.display=links.style.display==='flex'?'none':'flex';links.style.position='absolute';links.style.top='86px';links.style.right='0';links.style.left='0';links.style.background='#073f3b';links.style.padding='15px 5%';links.style.flexDirection='column';
});
function jumpToSurah(num){
  document.getElementById("quran-app")?.scrollIntoView({behavior:"smooth"});
  openSurah(num);
}
function updateProgress(){
  const raw=localStorage.getItem("zadLastRead");
  const pct=raw ? Math.min(100, Math.max(1, Math.round((Number(JSON.parse(raw).surah)-1)/113*100))) : 0;
  const bar=document.getElementById("progress-bar"), percent=document.getElementById("progress-percent"), text=document.getElementById("progress-text");
  if(bar)bar.style.width=pct+"%";
  if(percent)percent.textContent=pct+"%";
  if(text)text.textContent=raw ? `آخر موضع: سورة ${SURAH_NAMES[JSON.parse(raw).surah-1]}، الآية ${JSON.parse(raw).ayah}.` : "ابدأ قراءتك واحفظ موضعك ليظهر تقدمك هنا.";
}
function renderBookmarks(){
  const box=document.getElementById("bookmarks"); if(!box)return;
  const raw=JSON.parse(localStorage.getItem("zadBookmarks")||"[]");
  if(!raw.length){box.innerHTML="<p>لا توجد مواضع محفوظة بعد.</p>";return;}
  box.innerHTML=raw.slice(-8).reverse().map((b,i)=>`<div class="bookmark-row"><button onclick="openSurah(${b.surah},${b.ayah})">سورة ${SURAH_NAMES[b.surah-1]} • الآية ${b.ayah}</button><button onclick="removeBookmark(${raw.length-1-i})">حذف</button></div>`).join("");
}
function saveAyah(ayah){
  document.querySelectorAll(".ayah").forEach(x=>x.classList.remove("saved"));
  document.getElementById("ayah-"+ayah)?.classList.add("saved");
  savePosition(currentSurah,ayah);
  const arr=JSON.parse(localStorage.getItem("zadBookmarks")||"[]");
  if(!arr.some(b=>b.surah===currentSurah&&b.ayah===ayah))arr.push({surah:currentSurah,ayah});
  localStorage.setItem("zadBookmarks",JSON.stringify(arr.slice(-30)));
  renderBookmarks(); updateProgress();
}
function removeBookmark(index){
  const arr=JSON.parse(localStorage.getItem("zadBookmarks")||"[]");arr.splice(index,1);localStorage.setItem("zadBookmarks",JSON.stringify(arr));renderBookmarks();
}
function clearProgress(){
  if(confirm("هل تريد تصفير موضع القراءة والمفضلة؟")){
    localStorage.removeItem("zadLastRead");localStorage.removeItem("zadBookmarks");updateLastRead();updateProgress();renderBookmarks();
    document.querySelectorAll(".ayah").forEach(x=>x.classList.remove("saved"));
  }
}

function showAuth(type){
  document.getElementById("login-form").classList.toggle("hidden",type!=="login");
  document.getElementById("signup-form").classList.toggle("hidden",type!=="signup");
  document.querySelectorAll(".auth-tab").forEach((b,i)=>b.classList.toggle("active",(type==="login"&&i===0)||(type==="signup"&&i===1)));
}
function signupUser(){
  const name=document.getElementById("signup-name").value.trim(), email=document.getElementById("signup-email").value.trim(), pass=document.getElementById("signup-pass").value;
  if(!name||!email||pass.length<6){alert("أدخل الاسم والبريد وكلمة مرور من 6 أحرف على الأقل.");return;}
  localStorage.setItem("zadUser",JSON.stringify({name,email,pass}));
  localStorage.setItem("zadLoggedIn","1"); renderProfile(); alert("تم إنشاء الحساب التجريبي بنجاح.");
}
function loginUser(){
  const email=document.getElementById("login-email").value.trim(), pass=document.getElementById("login-pass").value;
  const u=JSON.parse(localStorage.getItem("zadUser")||"null");
  if(!u||u.email!==email||u.pass!==pass){alert("بيانات الدخول غير صحيحة أو لا يوجد حساب على هذا الجهاز.");return;}
  localStorage.setItem("zadLoggedIn","1");renderProfile();alert("تم تسجيل الدخول.");
}
function logoutUser(){localStorage.removeItem("zadLoggedIn");renderProfile();}
function renderProfile(){
  const u=JSON.parse(localStorage.getItem("zadUser")||"null"), logged=localStorage.getItem("zadLoggedIn")==="1";
  const box=document.getElementById("profile-box"), auth=document.getElementById("auth-box");
  if(!u||!logged){box?.classList.add("hidden");auth?.classList.remove("hidden");return;}
  auth?.classList.add("hidden");box?.classList.remove("hidden");
  document.getElementById("profile-name").textContent=u.name;document.getElementById("profile-email").textContent=u.email;
  document.getElementById("avatar").textContent=u.name.charAt(0);
  const raw=localStorage.getItem("zadLastRead"), bm=JSON.parse(localStorage.getItem("zadBookmarks")||"[]");
  const pct=raw?Math.min(100,Math.max(1,Math.round((JSON.parse(raw).surah-1)/113*100))):0;
  document.getElementById("stat-progress").textContent=pct+"%";document.getElementById("stat-bookmarks").textContent=bm.length;
  document.getElementById("stat-last").textContent=raw?SURAH_NAMES[JSON.parse(raw).surah-1]:"—";
}


/* ===== مسلم في القلب - SUPABASE CLOUD SYNC ===== */
let zadSupabase = null;
let cloudUser = null;

function initCloud(){
  if(window.supabase && window.ZAD_SUPABASE_URL && !String(window.ZAD_SUPABASE_URL).startsWith("YOUR_")){
    zadSupabase = window.supabase.createClient(window.ZAD_SUPABASE_URL, window.ZAD_SUPABASE_ANON_KEY);
    zadSupabase.auth.getSession().then(({data})=>{
      cloudUser=data.session?.user||null;
      updateCloudStatus();
    });
    zadSupabase.auth.onAuthStateChange((_event, session)=>{
      cloudUser=session?.user||null;
      updateCloudStatus();
      if(cloudUser) syncCloudData();
    });
  } else updateCloudStatus();
}
function updateCloudStatus(){
  const el=document.getElementById("cloud-status");
  if(!el)return;
  if(cloudUser){
    el.innerHTML="<span>☁️ المزامنة السحابية: مفعّلة</span><small>بياناتك مرتبطة بحسابك ويمكن مزامنتها بين الأجهزة.</small>";
    el.classList.add("cloud-on");
  } else {
    el.innerHTML="<span>☁️ المزامنة السحابية: غير مفعّلة بعد</span><small>أضف بيانات Supabase في ملف supabase-config.js لتفعيلها.</small>";
    el.classList.remove("cloud-on");
  }
}
async function cloudSignUp(email,password,name){
  if(!zadSupabase)return false;
  const {data,error}=await zadSupabase.auth.signUp({email,password,data:{full_name:name}});
  if(error){alert(error.message);return false;}
  if(data.user) await saveCloudProfile(data.user.id,name,email);
  return true;
}
async function cloudSignIn(email,password){
  if(!zadSupabase)return false;
  const {error}=await zadSupabase.auth.signInWithPassword({email,password});
  if(error){alert(error.message);return false;}
  return true;
}
async function cloudSignOut(){
  if(zadSupabase) await zadSupabase.auth.signOut();
}
async function saveCloudProfile(uid,name,email){
  if(!zadSupabase)return;
  await zadSupabase.from("profiles").upsert({id:uid,full_name:name,email});
}
async function syncCloudData(){
  if(!zadSupabase||!cloudUser)return;
  const payload={
    user_id:cloudUser.id,
    last_read:localStorage.getItem("zadLastRead")||null,
    bookmarks:JSON.parse(localStorage.getItem("zadBookmarks")||"[]"),
    updated_at:new Date().toISOString()
  };
  await zadSupabase.from("user_quran_data").upsert(payload,{onConflict:"user_id"});
}
async function loadCloudData(){
  if(!zadSupabase||!cloudUser)return;
  const {data,error}=await zadSupabase.from("user_quran_data").select("*").eq("user_id",cloudUser.id).maybeSingle();
  if(error||!data)return;
  if(data.last_read)localStorage.setItem("zadLastRead",data.last_read);
  if(data.bookmarks)localStorage.setItem("zadBookmarks",JSON.stringify(data.bookmarks));
  if(typeof renderBookmarks==="function")renderBookmarks();
  if(typeof updateLastRead==="function")updateLastRead();
  if(typeof updateProgress==="function")updateProgress();
  if(typeof renderProfile==="function")renderProfile();
}
const _oldSignupUser=window.signupUser;
window.signupUser=async function(){
  const name=document.getElementById("signup-name").value.trim();
  const email=document.getElementById("signup-email").value.trim();
  const pass=document.getElementById("signup-pass").value;
  if(zadSupabase){
    if(!name||!email||pass.length<6){alert("أدخل الاسم والبريد وكلمة مرور من 6 أحرف على الأقل.");return;}
    const ok=await cloudSignUp(email,pass,name);
    if(ok) alert("تم إنشاء الحساب. تحقق من بريدك الإلكتروني إذا طلب Supabase ذلك.");
  } else if(_oldSignupUser) _oldSignupUser();
};
const _oldLoginUser=window.loginUser;
window.loginUser=async function(){
  const email=document.getElementById("login-email").value.trim();
  const pass=document.getElementById("login-pass").value;
  if(zadSupabase){
    const ok=await cloudSignIn(email,pass);
    if(ok){alert("تم تسجيل الدخول بنجاح.");await loadCloudData();}
  } else if(_oldLoginUser) _oldLoginUser();
};
const _oldLogoutUser=window.logoutUser;
window.logoutUser=async function(){
  if(zadSupabase) await cloudSignOut();
  else if(_oldLogoutUser)_oldLogoutUser();
};
initCloud();

renderAdhkar();renderHadith();loadPrayerTimes();renderSurahList();updateLastRead();updateProgress();renderBookmarks();openSurah(1);renderProfile();


/* ===== ADMIN DASHBOARD ===== */
function toggleAdmin(){document.getElementById("admin-panel")?.classList.toggle("hidden")}
function adminLogin(){
 const p=document.getElementById("admin-pass").value;
 if(p!=="admin123"){alert("كلمة مرور المدير غير صحيحة.");return;}
 localStorage.setItem("zadAdmin","1");renderAdmin();
}
function renderAdmin(){
 const ok=localStorage.getItem("zadAdmin")==="1";
 document.getElementById("admin-login")?.classList.toggle("hidden",ok);
 document.getElementById("admin-content")?.classList.toggle("hidden",!ok);
 if(!ok)return;
 const users=JSON.parse(localStorage.getItem("zadUser")||"null");
 document.getElementById("a-users").textContent=users?1:0;
 document.getElementById("a-bookmarks").textContent=JSON.parse(localStorage.getItem("zadBookmarks")||"[]").length;
 renderAdminLists();
}
function addAdminHadith(){
 const text=document.getElementById("hadith-text").value.trim(),source=document.getElementById("hadith-source").value.trim(),explain=document.getElementById("hadith-explain").value.trim();
 if(!text)return alert("أدخل نص الحديث.");
 const a=JSON.parse(localStorage.getItem("zadAdminHadiths")||"[]");a.push({text,source,explain,date:new Date().toISOString()});localStorage.setItem("zadAdminHadiths",JSON.stringify(a));document.getElementById("hadith-text").value="";document.getElementById("hadith-source").value="";document.getElementById("hadith-explain").value="";renderAdminLists();
}
function addAdminDhikr(){
 const title=document.getElementById("dhikr-title").value.trim(),text=document.getElementById("dhikr-text").value.trim(),count=Number(document.getElementById("dhikr-count").value)||1;
 if(!text)return alert("أدخل نص الذكر.");
 const a=JSON.parse(localStorage.getItem("zadAdminDhikrs")||"[]");a.push({title,text,count,date:new Date().toISOString()});localStorage.setItem("zadAdminDhikrs",JSON.stringify(a));document.getElementById("dhikr-title").value="";document.getElementById("dhikr-text").value="";renderAdminLists();
}
function saveDailyContent(){
 const title=document.getElementById("daily-title").value.trim(),text=document.getElementById("daily-text").value.trim();
 if(!text)return alert("أدخل المحتوى اليومي.");
 localStorage.setItem("zadDailyContent",JSON.stringify({title,text,date:new Date().toISOString()}));alert("تم حفظ المحتوى اليومي.");
}
function renderAdminLists(){
 const h=JSON.parse(localStorage.getItem("zadAdminHadiths")||"[]"),d=JSON.parse(localStorage.getItem("zadAdminDhikrs")||"[]");
 document.getElementById("admin-hadith-list").innerHTML=h.length?h.map((x,i)=>`<div class="admin-item"><b>${i+1}. ${x.text}</b><br>${x.source||""}<br><small>${x.explain||""}</small></div>`).join(""):"<p class='auth-note'>لا توجد أحاديث مضافة.</p>";
 document.getElementById("admin-dhikr-list").innerHTML=d.length?d.map((x,i)=>`<div class="admin-item"><b>${i+1}. ${x.title||"ذكر"}</b> — ${x.text}<br><small>التكرار: ${x.count}</small></div>`).join(""):"<p class='auth-note'>لا توجد أذكار مضافة.</p>";
}
function exportAdminData(){
 const data={hadiths:JSON.parse(localStorage.getItem("zadAdminHadiths")||"[]"),dhikrs:JSON.parse(localStorage.getItem("zadAdminDhikrs")||"[]"),daily:JSON.parse(localStorage.getItem("zadDailyContent")||"null")};
 const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="zad-al-muslim-backup.json";a.click();URL.revokeObjectURL(a.href);
}
function clearAdminContent(){
 if(!confirm("حذف كل المحتوى المضاف محليًا؟"))return;
 ["zadAdminHadiths","zadAdminDhikrs","zadDailyContent"].forEach(k=>localStorage.removeItem(k));renderAdminLists();
}
renderAdmin();


/* ===== SECURE ADMIN CHECK ===== */
let zadIsAdmin=false;
async function checkCloudAdmin(){
  if(!zadSupabase||!cloudUser)return false;
  const {data,error}=await zadSupabase.from("profiles").select("role,full_name,email").eq("id",cloudUser.id).maybeSingle();
  if(error)return false;
  zadIsAdmin=data?.role==="admin";
  if(zadIsAdmin){
    localStorage.setItem("zadSecureAdmin","1");
    const note=document.getElementById("secure-admin-note");
    if(note)note.innerHTML="🔐 صلاحيات المدير مفعّلة من قاعدة البيانات.";
    renderAdmin();
  } else {
    localStorage.removeItem("zadSecureAdmin");
    document.getElementById("admin-content")?.classList.add("hidden");
  }
  return zadIsAdmin;
}
async function secureAdminLogin(){
  if(!zadSupabase){alert("فعّل Supabase أولًا لاستخدام دخول المدير الآمن.");return;}
  const email=document.getElementById("login-email")?.value.trim()||prompt("بريد المدير:");
  const pass=document.getElementById("login-pass")?.value||prompt("كلمة المرور:");
  if(!email||!pass)return;
  const ok=await cloudSignIn(email,pass);
  if(ok){
    await loadCloudData();
    if(!(await checkCloudAdmin())) alert("تم تسجيل الدخول، لكن هذا الحساب لا يملك صلاحية مدير.");
    else alert("تم فتح لوحة المدير الآمنة.");
  }
}
async function secureSaveHadith(item){
  if(!zadSupabase||!cloudUser||!zadIsAdmin)return false;
  const {error}=await zadSupabase.from("admin_content").insert({
    kind:"hadith",title:item.source||"حديث",content:item.text,extra:item.explain||""
  });
  if(error){alert(error.message);return false;}
  return true;
}
async function secureSaveDhikr(item){
  if(!zadSupabase||!cloudUser||!zadIsAdmin)return false;
  const {error}=await zadSupabase.from("admin_content").insert({
    kind:"dhikr",title:item.title||"ذكر",content:item.text,extra:String(item.count||1)
  });
  if(error){alert(error.message);return false;}
  return true;
}
async function loadSecureContent(){
  if(!zadSupabase||!cloudUser||!zadIsAdmin)return;
  const {data,error}=await zadSupabase.from("admin_content").select("*").order("created_at",{ascending:false});
  if(error)return;
  const h=(data||[]).filter(x=>x.kind==="hadith"), d=(data||[]).filter(x=>x.kind==="dhikr");
  document.getElementById("admin-hadith-list").innerHTML=h.length?h.map((x,i)=>`<div class="admin-item"><b>${i+1}. ${x.content}</b><br>${x.title||""}<br><small>${x.extra||""}</small></div>`).join(""):"<p class='auth-note'>لا توجد أحاديث مضافة.</p>";
  document.getElementById("admin-dhikr-list").innerHTML=d.length?d.map((x,i)=>`<div class="admin-item"><b>${i+1}. ${x.title||"ذكر"}</b> — ${x.content}<br><small>التكرار: ${x.extra||1}</small></div>`).join(""):"<p class='auth-note'>لا توجد أذكار مضافة.</p>";
}
const _oldAdminLogin=window.adminLogin;
window.adminLogin=async function(){
  if(zadSupabase){await secureAdminLogin();return;}
  if(_oldAdminLogin)_oldAdminLogin();
};
const _oldAddHadith=window.addAdminHadith;
window.addAdminHadith=async function(){
  if(zadSupabase&&cloudUser){
    if(!(await checkCloudAdmin())){alert("لا تملك صلاحية المدير.");return;}
    const text=document.getElementById("hadith-text").value.trim(),source=document.getElementById("hadith-source").value.trim(),explain=document.getElementById("hadith-explain").value.trim();
    if(!text)return alert("أدخل نص الحديث.");
    if(await secureSaveHadith({text,source,explain})){document.getElementById("hadith-text").value="";document.getElementById("hadith-source").value="";document.getElementById("hadith-explain").value="";await loadSecureContent();alert("تم حفظ الحديث في قاعدة البيانات.");}
    return;
  }
  if(_oldAddHadith)_oldAddHadith();
};
const _oldAddDhikr=window.addAdminDhikr;
window.addAdminDhikr=async function(){
  if(zadSupabase&&cloudUser){
    if(!(await checkCloudAdmin())){alert("لا تملك صلاحية المدير.");return;}
    const title=document.getElementById("dhikr-title").value.trim(),text=document.getElementById("dhikr-text").value.trim(),count=Number(document.getElementById("dhikr-count").value)||1;
    if(!text)return alert("أدخل نص الذكر.");
    if(await secureSaveDhikr({title,text,count})){document.getElementById("dhikr-title").value="";document.getElementById("dhikr-text").value="";await loadSecureContent();alert("تم حفظ الذكر في قاعدة البيانات.");}
    return;
  }
  if(_oldAddDhikr)_oldAddDhikr();
};
const _oldInitCloud=initCloud;
initCloud=async function(){
  _oldInitCloud();
  setTimeout(async()=>{if(zadSupabase&&cloudUser){await checkCloudAdmin();await loadSecureContent();}},1200);
};


/* ===== POLISH: THEME + GLOBAL SEARCH ===== */
function toggleTheme(){
  const dark=document.body.classList.toggle("dark");
  localStorage.setItem("zadTheme",dark?"dark":"light");
  const b=document.getElementById("theme-toggle"); if(b)b.textContent=dark?"☀️ الوضع النهاري":"🌙 الوضع الليلي";
}
function initTheme(){
  if(localStorage.getItem("zadTheme")==="dark"){
    document.body.classList.add("dark");
    const b=document.getElementById("theme-toggle"); if(b)b.textContent="☀️ الوضع النهاري";
  }
}
async function globalSearch(){
  const q=document.getElementById("site-search").value.trim(), box=document.getElementById("global-results");
  if(!q){box.innerHTML="";return;}
  box.innerHTML="<div class='global-result'>جاري البحث…</div>";
  try{
    const r=await fetch("https://api.alquran.cloud/v1/search/"+encodeURIComponent(q)+"/all/ar");
    const d=await r.json();
    const arr=d?.data?.matches||[];
    box.innerHTML=arr.slice(0,8).map(x=>`<div class="global-result"><b>القرآن — ${x.surah?.name||""}</b><br>${x.text||""}<br><small>الآية ${x.numberInSurah||""}</small></div>`).join("") || "<div class='global-result'>لم يتم العثور على نتائج.</div>";
  }catch(e){box.innerHTML="<div class='global-result'>تعذر البحث حاليًا. حاول مرة أخرى.</div>";}
}
initTheme();
