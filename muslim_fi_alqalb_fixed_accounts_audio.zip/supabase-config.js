// مسلم في القلب - إعدادات Supabase
// هذا Publishable Key آمن للاستخدام في المتصفح مع تفعيل RLS.
// لا تضع Secret/service_role key هنا.

window.ZAD_SUPABASE_URL = "https://sonzktdipwqgpwhwfcoy.supabase.co";
window.ZAD_SUPABASE_ANON_KEY = "sb_publishable_Mys-Bq1_tTKFMi9ENyj4jg_2zbl6MoT";
