مسلم في القلب — v10 Launch Ready

هذه النسخة مبنية على v9 وتضيف أساسيات الإطلاق:
- robots.txt
- sitemap.xml
- manifest.webmanifest
- service worker للتطبيق القابل للتثبيت وتحسين العمل مع الشبكات الضعيفة
- canonical URL placeholder

قبل النشر:
1) استبدل YOUR-DOMAIN.com بالدومين الحقيقي في index.html وsitemap.xml وrobots.txt.
2) ضع بيانات Supabase الحقيقية في supabase-config.js.
3) نفّذ supabase_schema.sql ثم supabase_admin_security.sql في مشروع Supabase.
4) أنشئ حساب المدير في Supabase Auth ثم اجعل role='admin' له من قاعدة البيانات.
5) فعّل HTTPS.
6) اختبر تسجيل الدخول، المزامنة، البحث، الصوت، مواقيت الصلاة، لوحة الإدارة على الهاتف والكمبيوتر.
7) راجع مصادر المحتوى وحقوق الاستخدام قبل الإطلاق العام.

طرق الاستضافة المناسبة:
- Vercel
- Netlify
- Cloudflare Pages
- أي استضافة static تدعم HTTPS

ملاحظة:
لا تضع Supabase service_role key داخل ملفات الموقع. استخدم anon/publishable key فقط في المتصفح.
