-- زاد المسلم: مخطط قاعدة بيانات Supabase
-- شغّل هذا الملف داخل Supabase SQL Editor.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  created_at timestamptz default now()
);

create table if not exists public.user_quran_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  last_read text,
  bookmarks jsonb default '[]'::jsonb,
  updated_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.user_quran_data enable row level security;

create policy "profiles own row" on public.profiles
for all using (auth.uid() = id) with check (auth.uid() = id);

create policy "quran data own row" on public.user_quran_data
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- بعد إنشاء المشروع، ضع URL و anon/publishable key في supabase-config.js.
